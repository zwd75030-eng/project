import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Signup({ onSignup }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirm: '',
  });
  const [error, setError] = useState(null);

  const handleChange = e =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();

    if (form.password !== form.confirm) {
      setError('Les mots de passe ne correspondent pas.');
      return;
    }

    const success = onSignup({
      name: form.name,
      email: form.email,
      password: form.password,
    });

    if (success) {
      alert(`Bienvenue, ${form.name} ! Votre compte est créé.`);
      navigate('/');
    } else {
      setError('Cet email est déjà utilisé.');
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #81c784, #4caf50)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '2rem',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      <div
        style={{
          backgroundColor: 'white',
          padding: '3rem 2.5rem',
          borderRadius: '16px',
          boxShadow: '0 12px 30px rgba(0, 0, 0, 0.15)',
          width: '100%',
          maxWidth: '400px',
          animation: 'fadeInUp 0.8s ease forwards',
        }}
      >
        <h1
          style={{
            textAlign: 'center',
            color: '#2e7d32',
            marginBottom: '2rem',
            fontWeight: '700',
            fontSize: '2.25rem',
            letterSpacing: '1px',
          }}
        >
          Créer un compte
        </h1>

        <form
          onSubmit={handleSubmit}
          style={{ display: 'flex', flexDirection: 'column', gap: '1.4rem' }}
        >
          {[
            { label: 'Nom complet', name: 'name', type: 'text', placeholder: 'Votre nom complet' },
            { label: 'Adresse e‑mail', name: 'email', type: 'email', placeholder: 'exemple@domaine.com' },
            { label: 'Mot de passe', name: 'password', type: 'password', placeholder: '••••••••' },
            { label: 'Confirmer le mot de passe', name: 'confirm', type: 'password', placeholder: '••••••••' },
          ].map(({ label, name, type, placeholder }) => (
            <label
              key={name}
              style={{ display: 'flex', flexDirection: 'column', fontWeight: '600', color: '#388e3c' }}
            >
              {label}
              <input
                name={name}
                type={type}
                required
                value={form[name]}
                onChange={handleChange}
                placeholder={placeholder}
                style={{
                  marginTop: '0.5rem',
                  padding: '0.75rem 1rem',
                  fontSize: '1rem',
                  borderRadius: '8px',
                  border: '2px solid #a5d6a7',
                  outline: 'none',
                  transition: 'border-color 0.3s ease',
                  fontFamily: 'inherit',
                }}
                onFocus={e => (e.target.style.borderColor = '#4caf50')}
                onBlur={e => (e.target.style.borderColor = '#a5d6a7')}
              />
            </label>
          ))}

          {error && (
            <p
              style={{
                color: '#e53935',
                fontWeight: '600',
                fontSize: '0.9rem',
                marginTop: '-0.5rem',
                marginBottom: '1rem',
                textAlign: 'center',
              }}
            >
              {error}
            </p>
          )}

          <button
            type="submit"
            style={{
              backgroundColor: '#4caf50',
              color: 'white',
              padding: '0.85rem',
              fontWeight: '700',
              fontSize: '1.1rem',
              border: 'none',
              borderRadius: '12px',
              cursor: 'pointer',
              boxShadow: '0 6px 12px rgba(76, 175, 80, 0.4)',
              transition: 'background-color 0.3s ease, box-shadow 0.3s ease',
            }}
            onMouseEnter={e => {
              e.target.style.backgroundColor = '#388e3c';
              e.target.style.boxShadow = '0 8px 18px rgba(56, 142, 60, 0.6)';
            }}
            onMouseLeave={e => {
              e.target.style.backgroundColor = '#4caf50';
              e.target.style.boxShadow = '0 6px 12px rgba(76, 175, 80, 0.4)';
            }}
          >
            S’inscrire
          </button>

          <button
            type="button"
            onClick={() => navigate('/')}
            style={{
              backgroundColor: 'transparent',
              color: '#4caf50',
              padding: '0.65rem',
              fontWeight: '600',
              fontSize: '1rem',
              border: '2px solid #4caf50',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'background-color 0.3s ease, color 0.3s ease',
            }}
            onMouseEnter={e => {
              e.target.style.backgroundColor = '#4caf50';
              e.target.style.color = 'white';
            }}
            onMouseLeave={e => {
              e.target.style.backgroundColor = 'transparent';
              e.target.style.color = '#4caf50';
            }}
          >
            Retour à l'accueil
          </button>
        </form>
      </div>

      {/* Add keyframes animation */}
      <style>{`
        @keyframes fadeInUp {
          0% {
            opacity: 0;
            transform: translateY(40px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
