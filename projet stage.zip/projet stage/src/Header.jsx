// Header.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Header({ user, setUser, setShowAuth }) {
  const navigate = useNavigate();

  return (
    <header>
      {/* your header JSX here */}
    </header>
  );
}
