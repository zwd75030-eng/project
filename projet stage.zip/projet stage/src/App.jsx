import React, { useState, useEffect } from 'react';
import './App.css';
import Signup from './signup';
import Login from './Login';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';

// PurchaseHistory Component
function PurchaseHistory({ user, purchaseHistory }) {
  const history = user ? purchaseHistory[user.email] || [] : [];
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  return (
    <div style={{ padding: '2rem', maxWidth: 800, margin: 'auto' }}>
      <button
        onClick={() => navigate('/')}
        style={{
          backgroundColor: '#4caf50',
          color: 'white',
          border: 'none',
          padding: '0.5rem 1rem',
          borderRadius: 5,
          cursor: 'pointer',
          fontWeight: 'bold',
          marginBottom: '1rem'
        }}
      >
        Back to Shop
      </button>
      
      <h2 style={{ color: '#2e7d32', marginBottom: '1rem' }}>Historique de vos achats</h2>

      {history.length === 0 ? (
        <p style={{ fontStyle: 'italic' }}>Aucun achat enregistré.</p>
      ) : (
        history.map((entry, i) => (
          <div key={i} style={{ border: '1px solid #ccc', borderRadius: 8, padding: '1rem', marginBottom: '1rem' }}>
            <h3 style={{ marginBottom: '0.5rem', color: '#4caf50' }}>Achat du {entry.date}</h3>
            <ul style={{ marginLeft: '1rem' }}>
              {entry.items.map(({ product, quantity }, idx) => (
                <li key={idx}>
                  {product.name} – {quantity} x ${product.price} = ${(product.price * quantity).toFixed(2)}
                </li>
              ))}
            </ul>
            <p style={{ fontWeight: 'bold', textAlign: 'right', marginTop: '0.5rem' }}>
              Total: ${entry.total}
            </p>
          </div>
        ))
      )}
    </div>
  );
}

// Header Component
function Header({ user, setUser }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    setUser(null);
    navigate('/');
  };

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        background: 'linear-gradient(135deg, #4caf50 0%, #81c784 100%)',
        color: 'white',
        padding: '1rem 2rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
        zIndex: 9999,
        flexWrap: 'wrap',
        gap: '1rem',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      <div style={{ flexGrow: 1, minWidth: 200 }}>
        <h1 style={{ margin: 0, fontSize: '1.75rem' }}>Office cherfienne de phosphate</h1>
        <p style={{ margin: '0.25rem 0 0', fontWeight: 'bold', fontSize: '0.9rem' }}>
          Quality products to help your plants grow strong and healthy.
        </p>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
        {!user ? (
          <>
            <button
              onClick={() => navigate('/login')}
              style={{
                backgroundColor: '#1976d2',
                border: 'none',
                color: 'white',
                padding: '0.4rem 1rem',
                borderRadius: 5,
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
            >
              Connexion
            </button>
            <button
              onClick={() => navigate('/signup')}
              style={{
                backgroundColor: '#4caf50',
                border: 'none',
                color: 'white',
                padding: '0.4rem 1rem',
                borderRadius: 5,
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
            >
              S'inscrire
            </button>
          </>
        ) : (
          <>
            <span style={{ fontWeight: 'bold' }}>Hello, {user.name}</span>
            <button
              onClick={() => navigate('/purchase-history')}
              style={{
                backgroundColor: '#1976d2',
                border: 'none',
                color: 'white',
                padding: '0.4rem 1rem',
                borderRadius: 5,
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
            >
              Purchase History
            </button>
            <button
              onClick={handleLogout}
              style={{
                backgroundColor: '#e53935',
                border: 'none',
                color: 'white',
                padding: '0.4rem 1rem',
                borderRadius: 5,
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
            >
              Déconnexion
            </button>
          </>
        )}
      </div>
    </header>
  );
}

// ShopHome Component
function ShopHome({
  filter,
  setFilter,
  filteredProducts,
  addToCart,
  cart,
  removeFromCart,
  totalItems,
  totalPrice,
  proceedToCheckout,
  showLoginPrompt,
  setShowLoginPrompt,
}) {
  const navigate = useNavigate();

  return (
    <>
      <section>
        <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem', color: '#2e7d32' }}>Our Products</h2>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '1.5rem',
          }}
        >
          <label style={{ fontWeight: 'bold', whiteSpace: 'nowrap', gridColumn: 'span 2' }}>
            Filter:{' '}
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              style={{ padding: '0.3rem 0.5rem', borderRadius: 5, border: 'none', fontWeight: 'bold' }}
            >
              <option value="All">All</option>
              <option value="Fertilizer">Fertilizer</option>
              <option value="Chemical">Chemical</option>
            </select>
          </label>

          {filteredProducts.map(({ id, name, description, price, image }) => (
            <div
              key={id}
              style={{
                backgroundColor: 'white',
                borderRadius: '12px',
                boxShadow: '0 6px 15px rgba(0,0,0,0.1)',
                overflow: 'hidden',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                cursor: 'default',
                display: 'flex',
                flexDirection: 'column',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 10px 25px rgba(0,0,0,0.2)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 6px 15px rgba(0,0,0,0.1)';
              }}
            >
              <img src={image} alt={name} style={{ width: '100%', height: '180px', objectFit: 'cover' }} />
              <div style={{ padding: '1rem', flexGrow: 1 }}>
                <h3 style={{ marginBottom: '0.5rem', color: '#388e3c' }}>{name}</h3>
                <p style={{ fontSize: '0.9rem', color: '#555', marginBottom: '1rem' }}>{description}</p>
                <strong style={{ fontSize: '1.1rem', color: '#2e7d32' }}>${price} / bag</strong>
              </div>
              <button
                onClick={() => addToCart({ id, name, description, price, image })}
                style={{
                  backgroundColor: '#4caf50',
                  color: 'white',
                  border: 'none',
                  padding: '0.75rem',
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  borderRadius: '0 0 12px 12px',
                  transition: 'background-color 0.3s ease',
                }}
                onMouseEnter={e => (e.target.style.backgroundColor = '#388e3c')}
                onMouseLeave={e => (e.target.style.backgroundColor = '#4caf50')}
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </section>

      <section style={{ marginTop: '3rem', backgroundColor: '#f9f9f9', padding: '1.5rem', borderRadius: 8 }}>
        <h2 style={{ color: '#2e7d32', marginBottom: '1rem' }}>Your Cart</h2>
        {totalItems === 0 ? (
          <p style={{ fontStyle: 'italic', color: '#555' }}>Your cart is empty.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #4caf50', textAlign: 'left', color: '#2e7d32' }}>
                  <th style={{ padding: '0.5rem' }}>Product</th>
                  <th style={{ padding: '0.5rem' }}>Quantity</th>
                  <th style={{ padding: '0.5rem' }}>Price per unit</th>
                  <th style={{ padding: '0.5rem' }}>Total price</th>
                  <th style={{ padding: '0.5rem' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {Object.values(cart).map(({ product, quantity }) => (
                  <tr key={product.id} style={{ borderBottom: '1px solid #ddd' }}>
                    <td style={{ padding: '0.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <img
                        src={product.image}
                        alt={product.name}
                        style={{ width: 60, height: 40, objectFit: 'cover', borderRadius: 6 }}
                      />
                      <span style={{ color: '#2e7d32', fontWeight: '600' }}>{product.name}</span>
                    </td>

                    <td style={{ padding: '0.5rem', color: '#333' }}>{quantity}</td>
                    <td style={{ padding: '0.5rem', color: '#333' }}>${product.price}</td>
                    <td style={{ padding: '0.5rem', color: '#333' }}>${(product.price * quantity).toFixed(2)}</td>

                    <td style={{ padding: '0.5rem' }}>
                      <button
                        onClick={() => removeFromCart(product.id)}
                        style={{
                          backgroundColor: '#e53935',
                          color: 'white',
                          border: 'none',
                          padding: '0.25rem 0.6rem',
                          cursor: 'pointer',
                          borderRadius: 4,
                        }}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <p
              style={{
                textAlign: 'right',
                marginTop: '1rem',
                fontWeight: 'bold',
                fontSize: '1.2rem',
                color: '#2e7d32',
              }}
            >
              Total: ${totalPrice.toFixed(2)}
            </p>

            {showLoginPrompt && (
              <div style={{ marginBottom: '1rem', textAlign: 'right' }}>
                <p style={{ fontWeight: 'bold', color: '#e65100', marginBottom: '0.5rem' }}>
                  Veuillez vous connecter ou vous inscrire pour continuer :
                </p>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                  <button
                    onClick={() => navigate('/login')}
                    style={{
                      backgroundColor: '#1976d2',
                      color: 'white',
                      padding: '0.5rem 1rem',
                      border: 'none',
                      borderRadius: 5,
                      cursor: 'pointer',
                      fontWeight: 'bold',
                    }}
                  >
                    Connexion
                  </button>
                  <button
                    onClick={() => navigate('/signup')}
                    style={{
                      backgroundColor: '#4caf50',
                      color: 'white',
                      padding: '0.5rem 1rem',
                      border: 'none',
                      borderRadius: 5,
                      cursor: 'pointer',
                      fontWeight: 'bold',
                    }}
                  >
                    S'inscrire
                  </button>
                </div>
              </div>
            )}

            <div style={{ textAlign: 'right' }}>
              <button
                onClick={proceedToCheckout}
                style={{
                  backgroundColor: '#1976d2',
                  color: 'white',
                  padding: '0.75rem 1.5rem',
                  border: 'none',
                  borderRadius: 6,
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  fontSize: '1rem',
                }}
                onMouseEnter={e => (e.target.style.backgroundColor = '#125aa2')}
                onMouseLeave={e => (e.target.style.backgroundColor = '#1976d2')}
              >
                Proceed to Checkout
              </button>
            </div>
          </>
        )}
      </section>
    </>
  );
}

// Product List
const allProducts = [
  {
    id: 1,
    name: 'Nitrogen Fertilizer',
    description: 'High-quality nitrogen fertilizer for crops.',
    price: 50,
    category: 'Fertilizer',
    image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 2,
    name: 'Phosphorus Fertilizer',
    description: 'Boosts root development and plant strength.',
    price: 45,
    category: 'Fertilizer',
    image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 3,
    name: 'Potassium Fertilizer',
    description: 'Improves drought resistance and yield.',
    price: 55,
    category: 'Fertilizer',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 4,
    name: 'Calcium Nitrate',
    description: 'Water-soluble fertilizer with calcium and nitrogen.',
    price: 60,
    category: 'Chemical',
    image: 'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 5,
    name: 'Sulfur Powder',
    description: 'Fine powder used as an agricultural chemical.',
    price: 40,
    category: 'Chemical',
    image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=400&q=80',
  },
];

export default function App() {
  const [filter, setFilter] = useState('All');
  const [cart, setCart] = useState({});
  const [user, setUser] = useState(null);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [users, setUsers] = useState([]);
  const [purchaseHistory, setPurchaseHistory] = useState({});

  const filteredProducts = filter === 'All' ? allProducts : allProducts.filter(p => p.category === filter);

  const addToCart = product => {
    setCart(prevCart => {
      const count = prevCart[product.id]?.quantity || 0;
      return {
        ...prevCart,
        [product.id]: {
          product,
          quantity: count + 1,
        },
      };
    });
  };

  const removeFromCart = productId => {
    setCart(prevCart => {
      const currentItem = prevCart[productId];
      if (!currentItem) return prevCart;
      if (currentItem.quantity === 1) {
        const { [productId]: _, ...rest } = prevCart;
        return rest;
      } else {
        return {
          ...prevCart,
          [productId]: {
            ...currentItem,
            quantity: currentItem.quantity - 1,
          },
        };
      }
    });
  };

  const totalItems = Object.values(cart).reduce((acc, item) => acc + item.quantity, 0);
  const totalPrice = Object.values(cart).reduce((acc, item) => acc + item.quantity * item.product.price, 0);

  const handleLogin = ({ email, password }) => {
    const foundUser = users.find(u => u.email === email && u.password === password);
    if (foundUser) {
      setUser({ name: foundUser.name, email: foundUser.email });
      setShowLoginPrompt(false);
      return true;
    }
    return false;
  };

  const handleSignup = ({ name, email, password }) => {
    if (users.find(u => u.email === email)) {
      return false;
    }
    setUsers(prev => [...prev, { name, email, password }]);
    setUser({ name, email });
    return true;
  };

  const proceedToCheckout = () => {
    if (!user) {
      setShowLoginPrompt(true);
    } else {
      alert(`Thank you for your purchase, ${user.name}! Total: $${totalPrice.toFixed(2)}`);
      
      // Save to purchase history
      const purchaseEntry = {
        date: new Date().toLocaleDateString(),
        items: Object.values(cart),
        total: totalPrice.toFixed(2)
      };
      
      setPurchaseHistory(prev => ({
        ...prev,
        [user.email]: [...(prev[user.email] || []), purchaseEntry]
      }));
      
      setCart({});
    }
  };

  return (
    <BrowserRouter>
      <Header user={user} setUser={setUser} />
      <div
        style={{
          fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
          maxWidth: 1200,
          margin: 'auto',
          padding: '6rem 1rem 1rem',
        }}
      >
        <Routes>
          <Route
            path="/"
            element={
              <ShopHome
                filter={filter}
                setFilter={setFilter}
                filteredProducts={filteredProducts}
                addToCart={addToCart}
                cart={cart}
                removeFromCart={removeFromCart}
                totalItems={totalItems}
                totalPrice={totalPrice}
                proceedToCheckout={proceedToCheckout}
                showLoginPrompt={showLoginPrompt}
                setShowLoginPrompt={setShowLoginPrompt}
              />
            }
          />
          <Route path="/signup" element={<Signup onSignup={handleSignup} />} />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
          <Route 
            path="/purchase-history" 
            element={<PurchaseHistory user={user} purchaseHistory={purchaseHistory} />} 
          />
        </Routes>

        <footer
          style={{
            marginTop: '4rem',
            padding: '1rem',
            textAlign: 'center',
            color: '#777',
            borderTop: '1px solid #ddd',
            fontSize: '0.9rem',
          }}
        >
          © 2000 OCP. All rights reserved.
        </footer>
      </div>
    </BrowserRouter>
  )
}