import React from 'react';

export default function PurchaseHistory({ user, purchaseHistory }) {
  const history = user ? purchaseHistory[user.email] || [] : [];

  return (
    <div style={{ padding: '2rem', maxWidth: 800, margin: 'auto' }}>
      <h2 style={{ color: '#2e7d32', marginBottom: '1rem' }}>Historique de vos achats</h2>

      {history.length === 0 ? (
        <p style={{ fontStyle: 'italic' }}>Aucun achat enregistré.</p>
      ) : (
        history.map((entry, i) => (
          <div key={i} style={{ border: '1px solid #ccc', borderRadius: 8, padding: '1rem', marginBottom: '1rem' }}>
            <h3 style={{ marginBottom: '0.5rem', color: '#4caf50' }}>Achat du {entry.date}</h3>
            <ul style={{ marginLeft: '1rem' }}>
              {entry.items.map(({ product, quantity }, idx) => (
                <li key={idx}>
                  {product.name} – {quantity} x ${product.price} = ${product.price * quantity}
                </li>
              ))}
            </ul>
            <p style={{ fontWeight: 'bold', textAlign: 'right', marginTop: '0.5rem' }}>
              Total: ${entry.total}
            </p>
          </div>
        ))
      )}
    </div>
  );
}
